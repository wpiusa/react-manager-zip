/*

import React, { Component } from 'react';
import { connect } from 'react-redux';
import { employeeUpdate, employeeCreate } from '../actions';
import { Card, CardSection, Button } from './common';
import EmployeeForm from './EmployeeForm';

class EmployeeCreate extends Component {
  onButtonPress() {
    const { name, phone, shift } = this.props;

    this.props.employeeCreate({ name, phone, shift: shift || 'Monday' });
  }

  render() {
    return (
      <Card>
        <EmployeeForm {...this.props} />
        <CardSection>
          <Button onPress={this.onButtonPress.bind(this)}>
            Create
          </Button>
        </CardSection>
      </Card>
    );
  }
}

const mapStateToProps = (state) => {
  const { name, phone, shift } = state.employeeForm;

  return { name, phone, shift };
};

export default connect(mapStateToProps, {
  employeeUpdate, employeeCreate
})(EmployeeCreate);
*/

import React, { Component } from 'react';
import { View, Text,Picker } from 'react-native';
import { employeeUpdate, employeeCreate } from '../actions';
class EmployeeCreate extends Component {
  onButtonPress() {
    const { name, phone, shift } = this.props;

    this.props.employeeCreate({ name, phone, shift: shift || 'Monday' });
  }

  render(){
    console.log(this.props)
    return(
      <Card>
        <CardSection style={{ flexDirection: 'column'}}>
          <Text style={styles.pickerTextStyle}>Shift</Text>
          <Picker
            style={{flex:1}}
            selectedValue={this.props.shift}
            onValueChange={value => this.props.employeeUpdate({prop:'shift'})}
          >
            <Picker.Item label="Monday" value="Monday" />
            <Picker.Item label="Monday" value="Monday" />
            <Picker.Item label="Monday" value="Monday" />
            <Picker.Item label="Monday" value="Monday" />
            <Picker.Item label="Monday" value="Monday" />
          </Picker>
        </CardSection>

        <CardSection>
          <Input 
            label="Name"
            placeholder="Jane"
            value={this.props.name}
            onChangeText={text => this.props.employeeUpdate({prop:'name', value:text})}
          />
        </CardSection>

        <CardSection>
          <Input 
            label="Phone"
            placeholder="444-333-3333"
          />
        </CardSection>
      </Card>
    );
  }
}  

const styles ={
  pickerTextStyle:{
    fontSize:18,
    paddingLeft:20
  }
}

const mapStateToProps = (state) => {
  const { name, phone, shift } = state.employeeForm;

  return { name, phone, shift };
};

export default connect(mapStateToProps, 
  {employeeUpdate,employeeCreate})(EmployeeCreate);