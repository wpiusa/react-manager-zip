/*

import {
  EMPLOYEES_FETCH_SUCCESS
} from '../actions/types';

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case EMPLOYEES_FETCH_SUCCESS:
      return action.payload;
    default:
      return state;
  }
};
*/

import {
  EMPLOYEE_UPDATE
} from '../actions/types';

const INITIAL_STATE = {
  name:'',
  phone:'',
  shift:'',
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
     case EMPLOYEES_FETCH_SUCCESS:
      //return {...state,[action.payload.prop]:action.payload};
    default:
      return state;
  }
};